HT = nil

TriggerEvent('HT_base:getBaseObjects', function(obj) 
    HT = obj 
end)

local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRPclient = Tunnel.getInterface("vRP", "ul-bank") 
vRP = Proxy.getInterface("vRP")

RegisterServerEvent("ul-bank:getBankAmount")
AddEventHandler("ul-bank:getBankAmount", function()
    local _source = source
    local user_id = vRP.getUserId({_source})
    local money = vRP.getBankMoney({user_id})
    local name = GetCharacterName(user_id)
    TriggerClientEvent("ul-bank:money", _source, money, name)
end)  

RegisterServerEvent("ul-bank:deposit")
AddEventHandler("ul-bank:deposit", function(depositAmount, depositDate)
    local _depositAmount = tonumber(depositAmount)
    local _source = source
    local user_id = vRP.getUserId({_source})
    if _depositAmount == nil or _depositAmount <= 0 or _depositAmount > vRP.getMoney({user_id}) then
        TriggerClientEvent("ul-bank:send:alert", -1, "error", "Udgyldigt Indsætnings antal")
    else
        vRP.tryPayment({user_id,_depositAmount})
        vRP.giveBankMoney({user_id,_depositAmount})
        TriggerClientEvent("ul-bank:send:alert", -1, "success", "Indsætning var vellykket")
        MySQL.Async.execute("INSERT INTO transactions (`user_id`, `type`, `amount`, `date`) VALUES (@user_id, @type, @amount, @date);", 
            {
                user_id = user_id,
                type = "Indsætning",
                amount = _depositAmount,
                date = depositDate

            }, function()
        end)
    end
end)


RegisterServerEvent("ul-bank:withdraw")
AddEventHandler("ul-bank:withdraw", function(withdrawAmount, withdrawDate)
    local _withdrawAmount = tonumber(withdrawAmount)
    local _source = source
    local user_id = vRP.getUserId({_source})
    base = vRP.getBankMoney({user_id})
    if _withdrawAmount == nil or _withdrawAmount <= 0 or _withdrawAmount > base then
        TriggerClientEvent("ul-bank:send:alert", -1, "error", "Ugyldigt Hæve antal")
    else
       vRP.giveMoney({user_id,_withdrawAmount})
       vRP.tryBankPayment({user_id, _withdrawAmount})
        TriggerClientEvent("ul-bank:send:alert", -1, "success", "Hævning var vellykket")
        MySQL.Async.execute("INSERT INTO transactions (`user_id`, `type`, `amount`, `date`) VALUES (@user_id, @type, @amount, @date);", 
            {
                user_id = user_id,
                type = "Hævning",
                amount = _withdrawAmount,
                date = withdrawDate
            
            }, function()
        end)
    end
end)

RegisterServerEvent("ul-bank:transfer")
AddEventHandler("ul-bank:transfer", function(transferAmount, transferDate, transferName)
    local _source = source
    local user_id = vRP.getUserId({_source})
    local target = tonumber(transferName)
    local Tsource = vRP.getUserSource({target})
    if (target == nil or target == -1 or Tsource == nil) then
        TriggerClientEvent("ul-bank:send:alert", _source, "error", "ID'et er ugyldigt")
    else
        balance = vRP.getBankMoney({user_id})
        tbalance = vRP.getBankMoney({target})

        if user_id == tonumber(transferName) then
            TriggerClientEvent("ul-bank:send:alert", _source, "error", "Du kan ikke overføre penge til dig selv.")
        else
            if balance <= 0 or balance < tonumber(transferAmount) or tonumber(transferAmount) <= 0 then
                TriggerClientEvent("ul-bank:send:alert", _source, "error", "Du har ikke penge nok i banken.")
            else
                vRP.tryBankPayment({user_id, tonumber(transferAmount)})
                vRP.giveBankMoney({target, tonumber(transferAmount)})
                local targetName = GetCharacterName(target)
                local name = GetCharacterName(user_id)
                TriggerClientEvent("ul-bank:send:alert", _source, "success", "Overførsel blev gennemført")
                TriggerClientEvent('mythic_notify:client:SendAlert', _source, { type = 'inform', text = 'Du overførte: '.. transferAmount ..' $ Til: '.. targetName, length = 5000})
                TriggerClientEvent('mythic_notify:client:SendAlert', vRP.getUserSource({target}), { type = 'inform', text = 'Du modtog: '.. transferAmount ..' $ Fra: '.. name, length = 5000})
                
                MySQL.Async.execute("INSERT INTO transactions (`user_id`, `type`, `amount`, `date`) VALUES (@user_id, @type, @amount, @date);", 
                    {
                        user_id = user_id,
                        type = "Overførte til: " .. targetName .. "",
                        amount = transferAmount,
                        date = transferDate
            
                    }, function()
                end)
                MySQL.Async.execute("INSERT INTO transactions (`user_id`, `type`, `amount`, `date`) VALUES (@user_id, @type, @amount, @date);", 
                {
                    user_id = target,
                    type = "Modtog Fra: " .. name .. "",
                    amount = transferAmount,
                    date = transferDate
        
                }, function()
            end)
            end
        end
    end
end)

HT.RegisterServerCallback('ul-bank:get:transactions', function(source, cb)
    local _source = source
    local user_id = vRP.getUserId({_source})

    MySQL.Async.fetchAll("SELECT * FROM transactions WHERE user_id = @user_id ORDER BY id DESC" , 
        {
            ['@user_id'] = user_id 
        }, function(transactions)
        cb(transactions)
    end)
end)


function GetCharacterName(user_id)
    local result = MySQL.Sync.fetchAll('SELECT firstname, name FROM vrp_user_identities WHERE user_id = @user_id', {
      ['@user_id'] = user_id
    })
  
    if result[1] and result[1].firstname and result[1].name then
      return ('%s %s'):format(result[1].firstname, result[1].name)
    end
  end
